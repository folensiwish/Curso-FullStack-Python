#Definimos los productos en un diccionario dentro de una lista
def catalogo():
    productos = [
        {
            'id': 1,
            'nombre': 'Mouse Razor x86',
            'categoria': 'Tecnologia',
            'precio': 85000,
        },
        {
            'id': 2,
            'nombre': 'Parlante mlab xt',
            'categoria': 'Tecnologia',
            'precio': 73000,
        },
        {
            'id': 3,
            'nombre': 'Teclado redragon',
            'categoria': 'Tecnologia',
            'precio': 20000,
        },
        {
            'id': 4,
            'nombre': 'Audifonos JBL 204',
            'categoria': 'Tecnologia',
            'precio': 35000,
        },
        {
            'id': 5,
            'nombre': 'Pantalla HP m24',
            'categoria': 'Tecnologia',
            'precio': 125000,
        }
    ]

    return productos