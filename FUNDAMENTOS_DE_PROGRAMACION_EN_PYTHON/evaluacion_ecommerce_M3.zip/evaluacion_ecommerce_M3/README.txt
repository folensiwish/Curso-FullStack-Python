- Este programa simula un ecommerce en consola de una tienda de periféricos de computador, donde el usuario puede visualizar un catálogo de productos tecnológicos como mouse, teclados, audífonos, parlante y pantallas. A través de un menú interactivo, el cliente puede buscar productos por nombre o categoría, agregarlos a un carrito de compras, ver el total a pagar y vaciar el carrito.

- Cómo ejecutar el programa:

1. Abre la terminal en tu editor de texto o consola y entra a la carpeta donde está el archivo.

2. Ejecuta el programa escribiendo:

python menu.py

3. Sigue las instrucciones del menú en pantalla.
