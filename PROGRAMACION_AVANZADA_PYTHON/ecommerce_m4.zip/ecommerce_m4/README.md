Ecommerce por cli - Programacion orientada a objetos

Este es un sistema de venta de articulos en este caso de tecnologias, como dice el titulo diseñado con POO que permite la interaccion de 2 usuarios con el sistema que serian el administrador que contiene facultades para hacer un crud y para el cliente hacer facultades de ver, añadir, comprar, buscar.
El sistema ademas permite exportar informacion de compras y catalogo de productos en archivos txt.

Como ejecutar el programa:

1. Abrir tu terminal preferida
2. Ubicar el directorio que contiene los archivos
3. Ejecutar el siguiente comando python tienda.py
4. Debe seleccionar el perfil en la cual quiere interactuar con el programa
5. Seguir intrucciones del Menú
