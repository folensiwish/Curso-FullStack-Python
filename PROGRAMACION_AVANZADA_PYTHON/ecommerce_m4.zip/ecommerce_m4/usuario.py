class Usuario:

    def __init__(self,nombre_usuario):
        self.nombre_usuario = nombre_usuario

    def __str__(self):
        return f'Usuario: {self.nombre}'
    


        