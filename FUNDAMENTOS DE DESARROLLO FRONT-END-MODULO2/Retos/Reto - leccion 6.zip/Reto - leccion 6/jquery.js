 $(document).ready(function() {
        $("a").click(function() {
            alert("Has pulsado el enlace...Ahora seras redireccionado a Google");
        });
    });